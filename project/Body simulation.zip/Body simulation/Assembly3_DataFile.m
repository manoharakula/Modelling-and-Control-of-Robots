% Simscape(TM) Multibody(TM) version: 7.3

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(26).translation = [0.0 0.0 0.0];
smiData.RigidTransform(26).angle = 0.0;
smiData.RigidTransform(26).axis = [0.0 0.0 0.0];
smiData.RigidTransform(26).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 0 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[body-1:-:]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [0 0 0];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(2).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(2).ID = 'F[body-1:-:]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [1000.0000000000002 6.6613381477509392e-13 250];  % mm
smiData.RigidTransform(3).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(3).axis = [1 0 0];
smiData.RigidTransform(3).ID = 'B[BLH-1:-:BLF-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-999.99999999999682 3.7630343285854906e-11 4.5474735088646412e-13];  % mm
smiData.RigidTransform(4).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(4).axis = [-1 1.508647025561734e-32 -1.108103068905242e-16];
smiData.RigidTransform(4).ID = 'F[BLH-1:-:BLF-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-1000.0000000000005 0 -2.2204460492503131e-13];  % mm
smiData.RigidTransform(5).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(5).axis = [1 0 0];
smiData.RigidTransform(5).ID = 'B[BLF-1:-:FLF-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [2879.3303902966586 1099.9705051986793 -1.7053025658242404e-13];  % mm
smiData.RigidTransform(6).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(6).axis = [-1 -5.1970411577545868e-33 4.1899023445120554e-17];
smiData.RigidTransform(6).ID = 'F[BLF-1:-:FLF-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [1875 1000.0010000000001 0];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[body-1:-:BLH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [-999.99999999999977 -1.6143530956469476e-11 -2000.0010000000009];  % mm
smiData.RigidTransform(8).angle = 1.5700924586837749e-16;  % rad
smiData.RigidTransform(8).axis = [-0.6676645132056418 0.74446228769889566 -3.9020805331237505e-17];
smiData.RigidTransform(8).ID = 'F[body-1:-:BLH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [-1000 2.2204460492503131e-13 0];  % mm
smiData.RigidTransform(9).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(9).axis = [1 0 0];
smiData.RigidTransform(9).ID = 'B[BLH-1:-:FLH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-1122.5343525178091 3747.9975096647481 9.0949470177292824e-13];  % mm
smiData.RigidTransform(10).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(10).axis = [1 -8.6819931620292196e-34 -1.1074516740377978e-16];
smiData.RigidTransform(10).ID = 'F[BLH-1:-:FLH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [999.99999999999977 6.6613381477509392e-13 250.00000000000011];  % mm
smiData.RigidTransform(11).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(11).axis = [1 0 0];
smiData.RigidTransform(11).ID = 'B[BRH-1:-:BRF-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-1000.0000000000093 1.6370904631912708e-11 500.00000000000023];  % mm
smiData.RigidTransform(12).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(12).axis = [-1 -5.1801617113555721e-32 2.0990662669765466e-16];
smiData.RigidTransform(12).ID = 'F[BRH-1:-:BRF-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [-999.99999999999955 4.4408920985006262e-13 250];  % mm
smiData.RigidTransform(13).angle = 0;  % rad
smiData.RigidTransform(13).axis = [0 0 0];
smiData.RigidTransform(13).ID = 'B[BRF-1:-:FRF-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [1824.8736866063891 3721.344022233885 250.00000000000045];  % mm
smiData.RigidTransform(14).angle = 6.1204033705575123e-16;  % rad
smiData.RigidTransform(14).axis = [-0.6403400391209676 -0.76809155333108403 1.5051289092862305e-16];
smiData.RigidTransform(14).ID = 'F[BRF-1:-:FRF-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [1875 1000.0010000000001 0];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(15).ID = 'B[body-1:-:BRH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-1000.0000000000045 2.0179413695586845e-12 249.99899999999911];  % mm
smiData.RigidTransform(16).angle = 2.7755575615628914e-16;  % rad
smiData.RigidTransform(16).axis = [0.99265065922444007 0.12101515913836733 1.6670800503222734e-17];
smiData.RigidTransform(16).ID = 'F[body-1:-:BRH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [-1000 2.2204460492503131e-13 250];  % mm
smiData.RigidTransform(17).angle = 0;  % rad
smiData.RigidTransform(17).axis = [0 0 0];
smiData.RigidTransform(17).ID = 'B[BRH-1:-:FRH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [-3581.3888067973558 2720.0977607691466 250.00000000000227];  % mm
smiData.RigidTransform(18).angle = 3.5108334685767012e-16;  % rad
smiData.RigidTransform(18).axis = [-0.99798816377317223 0.063400512369002293 -1.1107041442943158e-17];
smiData.RigidTransform(18).ID = 'F[BRH-1:-:FRH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [1000.0000000000002 4.4408920985006262e-13 249.99999999999977];  % mm
smiData.RigidTransform(19).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(19).axis = [1 0 0];
smiData.RigidTransform(19).ID = 'B[FLH-1:-:FLF-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [-999.99999999999932 2.1600499167107046e-12 -6.8212102632969618e-13];  % mm
smiData.RigidTransform(20).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(20).axis = [-1 1.5647709918861279e-33 -3.9710924368099663e-17];
smiData.RigidTransform(20).ID = 'F[FLH-1:-:FLF-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [-1875 1000.0010000000001 -1.6409810457051864e-13];  % mm
smiData.RigidTransform(21).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(21).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(21).ID = 'B[body-1:-:FLH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [-1000.0000000000045 -1.8189894035458565e-12 -2000.0009999999991];  % mm
smiData.RigidTransform(22).angle = 3.3766115072321297e-16;  % rad
smiData.RigidTransform(22).axis = [-0.1804948093081899 0.98357593698341361 -2.9972551334871227e-17];
smiData.RigidTransform(22).ID = 'F[body-1:-:FLH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [-1000 0 250];  % mm
smiData.RigidTransform(23).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(23).axis = [1 0 0];
smiData.RigidTransform(23).ID = 'B[FRF-1:-:FRH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [1000.000000000005 1.1084466677857563e-11 4.5474735088646412e-13];  % mm
smiData.RigidTransform(24).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(24).axis = [1 -1.422377102146647e-32 -1.1557332529446594e-16];
smiData.RigidTransform(24).ID = 'F[FRF-1:-:FRH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [-1875 1000.0010000000001 -1.6409810457051864e-13];  % mm
smiData.RigidTransform(25).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(25).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(25).ID = 'B[body-1:-:FRH-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [-1000.0000000000036 2.7284841053187847e-12 249.9990000000011];  % mm
smiData.RigidTransform(26).angle = 3.7238012298709097e-16;  % rad
smiData.RigidTransform(26).axis = [-0.74682013800525393 0.6650260757818548 -9.2472199984354645e-17];
smiData.RigidTransform(26).ID = 'F[body-1:-:FRH-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(9).mass = 0.0;
smiData.Solid(9).CoM = [0.0 0.0 0.0];
smiData.Solid(9).MoI = [0.0 0.0 0.0];
smiData.Solid(9).PoI = [0.0 0.0 0.0];
smiData.Solid(9).color = [0.0 0.0 0.0];
smiData.Solid(9).opacity = 0.0;
smiData.Solid(9).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 274.54369260617023;  % kg
smiData.Solid(1).CoM = [0 0 125];  % mm
smiData.Solid(1).MoI = [7309364.9936904358 120394724.2665273 124844259.12890346];  % kg*mm^2
smiData.Solid(1).PoI = [0 0 -2.1499852838598825e-08];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'FLF*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 274.54369260617017;  % kg
smiData.Solid(2).CoM = [0 0 125];  % mm
smiData.Solid(2).MoI = [7309364.9936904358 120394724.2665273 124844259.12890346];  % kg*mm^2
smiData.Solid(2).PoI = [0 0 -2.1499852838598825e-08];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'FLH*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 274.54369260617023;  % kg
smiData.Solid(3).CoM = [0 0 125];  % mm
smiData.Solid(3).MoI = [7309364.9936904358 120394724.26652732 124844259.12890349];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 -2.1499852838598825e-08];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'BLH*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 274.54369260617023;  % kg
smiData.Solid(4).CoM = [0 0 125];  % mm
smiData.Solid(4).MoI = [7309364.9936904358 120394724.26652732 124844259.12890349];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 -2.1499852838598825e-08];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'BLF*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 9802.6972563434301;  % kg
smiData.Solid(5).CoM = [-0.22115283760025528 0.06201036659471644 -0.048133220605377509];  % mm
smiData.Solid(5).MoI = [4099825014.3541665 20969660581.685909 23404820088.505592];  % kg*mm^2
smiData.Solid(5).PoI = [-300924.33967450372 1073212.0333517005 -1382626.60975073];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'body*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 274.54369260617017;  % kg
smiData.Solid(6).CoM = [0 0 125];  % mm
smiData.Solid(6).MoI = [7309364.9936904358 120394724.2665273 124844259.12890346];  % kg*mm^2
smiData.Solid(6).PoI = [0 0 -2.1499852838598825e-08];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'BRF*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 274.54369260617023;  % kg
smiData.Solid(7).CoM = [0 0 125];  % mm
smiData.Solid(7).MoI = [7309364.9936904358 120394724.2665273 124844259.12890346];  % kg*mm^2
smiData.Solid(7).PoI = [0 0 -2.1499852838598825e-08];  % kg*mm^2
smiData.Solid(7).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'BRH*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 274.54369260617017;  % kg
smiData.Solid(8).CoM = [0 0 125];  % mm
smiData.Solid(8).MoI = [7309364.9936904348 120394724.2665273 124844259.12890346];  % kg*mm^2
smiData.Solid(8).PoI = [0 0 -2.1499852838598825e-08];  % kg*mm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'FRH*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 274.54369260617017;  % kg
smiData.Solid(9).CoM = [0 0 125];  % mm
smiData.Solid(9).MoI = [7309364.9936904358 120394724.2665273 124844259.12890346];  % kg*mm^2
smiData.Solid(9).PoI = [0 0 -2.1499852838598825e-08];  % kg*mm^2
smiData.Solid(9).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = 'FRF*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(4).Rz.Pos = 0.0;
smiData.CylindricalJoint(4).Pz.Pos = 0.0;
smiData.CylindricalJoint(4).ID = '';

smiData.CylindricalJoint(1).Rz.Pos = -41.414598371285059;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(1).ID = '[BLH-1:-:BLF-1]';

smiData.CylindricalJoint(2).Rz.Pos = -173.77413142996687;  % deg
smiData.CylindricalJoint(2).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(2).ID = '[body-1:-:BLH-1]';

smiData.CylindricalJoint(3).Rz.Pos = 74.674570169391899;  % deg
smiData.CylindricalJoint(3).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(3).ID = '[FRF-1:-:FRH-1]';

smiData.CylindricalJoint(4).Rz.Pos = 136.49875412834675;  % deg
smiData.CylindricalJoint(4).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(4).ID = '[body-1:-:FRH-1]';


%Initialize the PlanarJoint structure array by filling in null values.
smiData.PlanarJoint(4).Rz.Pos = 0.0;
smiData.PlanarJoint(4).Px.Pos = 0.0;
smiData.PlanarJoint(4).Py.Pos = 0.0;
smiData.PlanarJoint(4).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(1).Rz.Pos = -26.681469623315618;  % deg
smiData.PlanarJoint(1).Px.Pos = 0;  % mm
smiData.PlanarJoint(1).Py.Pos = 0;  % mm
smiData.PlanarJoint(1).ID = '[BLF-1:-:FLF-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(2).Rz.Pos = 8.0983888874783609;  % deg
smiData.PlanarJoint(2).Px.Pos = 0;  % mm
smiData.PlanarJoint(2).Py.Pos = 0;  % mm
smiData.PlanarJoint(2).ID = '[BLH-1:-:FLH-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(3).Rz.Pos = -34.42683212281058;  % deg
smiData.PlanarJoint(3).Px.Pos = 0;  % mm
smiData.PlanarJoint(3).Py.Pos = 0;  % mm
smiData.PlanarJoint(3).ID = '[BRF-1:-:FRF-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(4).Rz.Pos = -29.599858059875242;  % deg
smiData.PlanarJoint(4).Px.Pos = 0;  % mm
smiData.PlanarJoint(4).Py.Pos = 0;  % mm
smiData.PlanarJoint(4).ID = '[BRH-1:-:FRH-1]';


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(4).Rz.Pos = 0.0;
smiData.RevoluteJoint(4).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = -79.501544232327248;  % deg
smiData.RevoluteJoint(1).ID = '[BRH-1:-:BRF-1]';

smiData.RevoluteJoint(2).Rz.Pos = 166.09861218822198;  % deg
smiData.RevoluteJoint(2).ID = '[body-1:-:BRH-1]';

smiData.RevoluteJoint(3).Rz.Pos = -76.194456882079038;  % deg
smiData.RevoluteJoint(3).ID = '[FLH-1:-:FLF-1]';

smiData.RevoluteJoint(4).Rz.Pos = 178.12747968255476;  % deg
smiData.RevoluteJoint(4).ID = '[body-1:-:FLH-1]';

